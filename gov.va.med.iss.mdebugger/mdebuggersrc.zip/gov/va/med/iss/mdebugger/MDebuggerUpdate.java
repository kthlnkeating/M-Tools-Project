package gov.va.med.iss.mdebugger;

public class MDebuggerUpdate {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	static public void UpdateDisplays(String input) {
		
	}

}
